package com.zosh.tasknotificationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskNotificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
