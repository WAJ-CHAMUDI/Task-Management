package com.zosh.userservice.exception;

public class UserException extends Exception {
	
	public UserException(String message) {
		super(message);
	}

}
